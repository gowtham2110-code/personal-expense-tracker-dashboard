
import Dashboard from "../components/Dashboard";
import TransactionForm from "../components/TransactionForm";
import TransactionList from "../components/TransactionList";

function Home({
  transactions,
  addTransaction,
  deleteTransaction,
  income,
  expenses,
  balance,
}) {
  return (
    <div className="page-container">
      <div className="page-title">
        <div>
          <h1>Dashboard</h1>
          <p>Track your income and expenses in one place.</p>
        </div>
      </div>

      <Dashboard
        income={income}
        expenses={expenses}
        balance={balance}
      />

      <div className="content-grid">
        <TransactionForm addTransaction={addTransaction} />

        <div className="transaction-section">
          <TransactionList
            transactions={transactions}
            deleteTransaction={deleteTransaction}
          />
        </div>
      </div>
    </div>
  );
}

export default Home;
