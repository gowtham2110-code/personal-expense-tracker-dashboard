
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";

function Reports({ transactions }) {
  const expenses = transactions.filter(
    (t) => t.type === "expense"
  );

  const categoryData = Object.values(
    expenses.reduce((acc, item) => {
      acc[item.category] ??= {
        name: item.category,
        value: 0,
      };

      acc[item.category].value += Number(item.amount);
      return acc;
    }, {})
  );

  const monthlyData = Object.values(
    transactions.reduce((acc, item) => {
      const month = item.date.slice(0, 7);

      acc[month] ??= {
        month,
        income: 0,
        expenses: 0,
      };

      if (item.type === "income") {
        acc[month].income += Number(item.amount);
      } else {
        acc[month].expenses += Number(item.amount);
      }

      return acc;
    }, {})
  ).sort((a, b) => a.month.localeCompare(b.month));

  const COLORS = [
    "#7C3AED",
    "#06B6D4",
    "#F59E0B",
    "#EF4444",
    "#10B981",
    "#EC4899",
    "#64748B",
  ];

  const money = (value) =>
    "₹" + Number(value).toLocaleString("en-IN");

  return (
    <div className="page-container">
      <div className="page-title">
        <div>
          <h1>Reports & Analytics</h1>
          <p>Understand your spending habits.</p>
        </div>
      </div>

      <div className="reports-grid">
        <div className="panel chart-panel">
          <h3>Expenses by Category</h3>

          {categoryData.length === 0 ? (
            <p className="empty-state">No expense data available.</p>
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={categoryData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  label
                >
                  {categoryData.map((entry, index) => (
                    <Cell
                      key={entry.name}
                      fill={COLORS[index % COLORS.length]}
                    />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => money(value)} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="panel chart-panel">
          <h3>Income vs Expenses</h3>

          {monthlyData.length === 0 ? (
            <p className="empty-state">No transaction data available.</p>
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value) => money(value)} />
                <Bar dataKey="income" fill="#10B981" radius={[5, 5, 0, 0]} />
                <Bar dataKey="expenses" fill="#EF4444" radius={[5, 5, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  );
}

export default Reports;
