
import { LayoutDashboard, ChartNoAxesColumn, Wallet } from "lucide-react";

function Sidebar({ activePage, setActivePage }) {
  return (
    <aside className="sidebar">
      <div className="logo">
        <Wallet size={28} />
        <h2>SpendWise</h2>
      </div>

      <p className="menu-label">MENU</p>

      <button
        className={activePage === "Dashboard" ? "nav-item active" : "nav-item"}
        onClick={() => setActivePage("Dashboard")}
      >
        <LayoutDashboard size={20} />
        Dashboard
      </button>

      <button
        className={activePage === "Reports" ? "nav-item active" : "nav-item"}
        onClick={() => setActivePage("Reports")}
      >
        <ChartNoAxesColumn size={20} />
        Reports
      </button>

      <div className="sidebar-footer">
        <p>Personal Finance Manager</p>
        <span>Manage your money wisely.</span>
      </div>
    </aside>
  );
}

export default Sidebar;
