
import { Bell, UserCircle } from "lucide-react";

function Navbar() {
  return (
    <header className="navbar">
      <div>
        <p className="welcome-text">Welcome back!</p>
        <h3>Financial Overview</h3>
      </div>

      <div className="navbar-right">
        <button className="icon-btn" aria-label="Notifications">
          <Bell size={20} />
        </button>

        <div className="profile">
          <UserCircle size={34} />
          <div>
            <strong>My Account</strong>
            <span>Personal User</span>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Navbar;
