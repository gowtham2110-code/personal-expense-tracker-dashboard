
import { Wallet, TrendingUp, TrendingDown } from "lucide-react";

function Dashboard({ income, expenses, balance }) {
  const formatMoney = (amount) =>
    new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount);

  const cards = [
    {
      title: "Total Balance",
      amount: balance,
      icon: <Wallet />,
      color: "purple",
    },
    {
      title: "Total Income",
      amount: income,
      icon: <TrendingUp />,
      color: "green",
    },
    {
      title: "Total Expenses",
      amount: expenses,
      icon: <TrendingDown />,
      color: "red",
    },
  ];

  return (
    <div className="dashboard-cards">
      {cards.map((card) => (
        <div className="stat-card" key={card.title}>
          <div className="stat-top">
            <span>{card.title}</span>
            <div className={`stat-icon ${card.color}`}>
              {card.icon}
            </div>
          </div>

          <h2>{formatMoney(card.amount)}</h2>
          <p>Updated with your transactions</p>
        </div>
      ))}
    </div>
  );
}

export default Dashboard;
