
import { useState } from "react";
import { Plus } from "lucide-react";

function TransactionForm({ addTransaction }) {
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("Food");
  const [type, setType] = useState("expense");
  const [date, setDate] = useState(
    new Date().toISOString().split("T")[0]
  );

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!title.trim() || !amount || Number(amount) <= 0) {
      alert("Please enter valid transaction details.");
      return;
    }

    addTransaction({
      title: title.trim(),
      amount: Number(amount),
      category: type === "income" ? "Income" : category,
      type,
      date,
    });

    setTitle("");
    setAmount("");
    setCategory("Food");
    setType("expense");
    setDate(new Date().toISOString().split("T")[0]);
  };

  return (
    <div className="panel">
      <div className="panel-heading">
        <h3>Add Transaction</h3>
        <Plus size={21} />
      </div>

      <form onSubmit={handleSubmit} className="transaction-form">
        <label>Transaction Name</label>
        <input
          type="text"
          placeholder="e.g. Grocery Shopping"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />

        <label>Amount (₹)</label>
        <input
          type="number"
          placeholder="Enter amount"
          min="0.01"
          step="0.01"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          required
        />

        <label>Transaction Type</label>
        <select value={type} onChange={(e) => setType(e.target.value)}>
          <option value="expense">Expense</option>
          <option value="income">Income</option>
        </select>

        {type === "expense" && (
          <>
            <label>Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              <option>Food</option>
              <option>Travel</option>
              <option>Shopping</option>
              <option>Bills</option>
              <option>Entertainment</option>
              <option>Health</option>
              <option>Other</option>
            </select>
          </>
        )}

        <label>Date</label>
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          required
        />

        <button className="submit-btn" type="submit">
          <Plus size={18} /> Add Transaction
        </button>
      </form>
    </div>
  );
}

export default TransactionForm;
