
import { Trash2, ArrowDownLeft, ArrowUpRight } from "lucide-react";

function TransactionList({ transactions, deleteTransaction }) {
  const formatMoney = (amount) =>
    new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount);

  return (
    <div className="panel">
      <div className="panel-heading">
        <h3>Recent Transactions</h3>
        <span className="transaction-count">
          {transactions.length} Records
        </span>
      </div>

      <div className="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Category</th>
              <th>Date</th>
              <th>Amount</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
            {transactions.length === 0 ? (
              <tr>
                <td colSpan="5" className="empty-state">
                  No transactions yet. Add your first transaction!
                </td>
              </tr>
            ) : (
              transactions.map((item) => (
                <tr key={item.id}>
                  <td>
                    <div className="transaction-name">
                      <span className={`transaction-symbol ${item.type}`}>
                        {item.type === "income" ? (
                          <ArrowDownLeft size={18} />
                        ) : (
                          <ArrowUpRight size={18} />
                        )}
                      </span>
                      <strong>{item.title}</strong>
                    </div>
                  </td>

                  <td>{item.category}</td>
                  <td>{item.date}</td>

                  <td className={item.type === "income" ? "income-text" : "expense-text"}>
                    {item.type === "income" ? "+" : "-"}
                    {formatMoney(item.amount)}
                  </td>

                  <td>
                    <button
                      className="delete-btn"
                      onClick={() => deleteTransaction(item.id)}
                      aria-label={`Delete ${item.title}`}
                    >
                      <Trash2 size={18} />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default TransactionList;
