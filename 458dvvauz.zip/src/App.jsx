
import { useEffect, useState } from "react";
import Sidebar from "./components/Sidebar";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Reports from "./pages/Reports";

function App() {
  const [activePage, setActivePage] = useState("Dashboard");

  const [transactions, setTransactions] = useState(() => {
    const saved = localStorage.getItem("transactions");
    return saved ? JSON.parse(saved) : [
      { id: 1, title: "Salary", category: "Income", amount: 35000, type: "income", date: "2026-11-01" },
      { id: 2, title: "Groceries", category: "Food", amount: 2500, type: "expense", date: "2026-11-02" },
      { id: 3, title: "Electricity Bill", category: "Bills", amount: 1200, type: "expense", date: "2026-11-03" },
      { id: 4, title: "Freelance Work", category: "Income", amount: 5000, type: "income", date: "2026-11-04" },
    ];
  });

  useEffect(() => {
    localStorage.setItem("transactions", JSON.stringify(transactions));
  }, [transactions]);

  const addTransaction = (transaction) => {
    setTransactions((prev) => [
      { ...transaction, id: Date.now() },
      ...prev,
    ]);
  };

  const deleteTransaction = (id) => {
    setTransactions((prev) => prev.filter((item) => item.id !== id));
  };

  const income = transactions
    .filter((t) => t.type === "income")
    .reduce((sum, t) => sum + Number(t.amount), 0);

  const expenses = transactions
    .filter((t) => t.type === "expense")
    .reduce((sum, t) => sum + Number(t.amount), 0);

  const balance = income - expenses;

  return (
    <div className="app">
      <Sidebar
        activePage={activePage}
        setActivePage={setActivePage}
      />

      <main className="main-content">
        <Navbar />

        {activePage === "Dashboard" ? (
          <Home
            transactions={transactions}
            addTransaction={addTransaction}
            deleteTransaction={deleteTransaction}
            income={income}
            expenses={expenses}
            balance={balance}
          />
        ) : (
          <Reports transactions={transactions} />
        )}
      </main>
    </div>
  );
}

export default App;
